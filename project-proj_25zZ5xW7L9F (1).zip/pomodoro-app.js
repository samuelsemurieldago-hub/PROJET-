function PomodoroApp() {
  try {
    const [subjects, setSubjects] = React.useState([]);
    const [selectedSubject, setSelectedSubject] = React.useState(null);
    const [duration, setDuration] = React.useState(25);
    const [timeLeft, setTimeLeft] = React.useState(duration * 60);
    const [isRunning, setIsRunning] = React.useState(false);
    const [isComplete, setIsComplete] = React.useState(false);

    React.useEffect(() => {
      setSubjects(StorageManager.getSubjects());
    }, []);

    React.useEffect(() => {
      setTimeLeft(duration * 60);
    }, [duration]);

    React.useEffect(() => {
      let interval = null;
      if (isRunning && timeLeft > 0) {
        interval = setInterval(() => {
          setTimeLeft(time => {
            if (time <= 1) {
              setIsRunning(false);
              setIsComplete(true);
              return 0;
            }
            return time - 1;
          });
        }, 1000);
      }
      return () => clearInterval(interval);
    }, [isRunning, timeLeft]);

    const formatTime = (seconds) => {
      const mins = Math.floor(seconds / 60);
      const secs = seconds % 60;
      return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    };

    const handleStart = () => {
      if (!selectedSubject) {
        alert('Veuillez sélectionner une matière');
        return;
      }
      setIsRunning(true);
    };

    const handleQualitySubmit = (quality) => {
      const subject = subjects.find(s => s.id === selectedSubject);
      const updatedSubject = SM2Algorithm.updateSubjectAfterSession(subject, quality);
      const updatedSubjects = subjects.map(s => s.id === selectedSubject ? updatedSubject : s);
      StorageManager.saveSubjects(updatedSubjects);
      StorageManager.addSession({
        subjectId: selectedSubject,
        subjectName: subject.name,
        duration: duration,
        quality: quality
      });
      setIsComplete(false);
      setTimeLeft(duration * 60);
      setSelectedSubject(null);
    };

    const progress = ((duration * 60 - timeLeft) / (duration * 60)) * 100;

    return (
      <div className="min-h-screen" data-name="pomodoro-app" data-file="pomodoro-app.js">
        <Navigation currentPage="pomodoro" />
        <div className="container mx-auto px-4 py-8 max-w-2xl">
          <h1 className="text-3xl font-bold mb-6 text-center">Session Pomodoro</h1>

          {!isComplete ? (
            <div className="card text-center">
              <div className="mb-6">
                <select
                  className="w-full px-4 py-2 rounded-lg border"
                  style={{borderColor: 'var(--border-color)'}}
                  value={selectedSubject || ''}
                  onChange={(e) => setSelectedSubject(e.target.value)}
                  disabled={isRunning}
                >
                  <option value="">Sélectionner une matière</option>
                  {subjects.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>

              <div className="mb-6">
                <label className="block mb-2 font-medium">Durée (minutes)</label>
                <div className="flex justify-center space-x-2">
                  {[25, 35, 50].map(d => (
                    <button
                      key={d}
                      onClick={() => setDuration(d)}
                      disabled={isRunning}
                      className={`px-4 py-2 rounded-lg ${duration === d ? 'btn-primary' : 'bg-gray-200'}`}
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>

              <div className="my-8">
                <div className="text-6xl font-bold mb-4" style={{color: 'var(--primary-color)'}}>
                  {formatTime(timeLeft)}
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
                  <div
                    className="h-3 rounded-full transition-all"
                    style={{backgroundColor: 'var(--primary-color)', width: `${progress}%`}}
                  ></div>
                </div>
              </div>

              <div className="flex justify-center space-x-4">
                {!isRunning ? (
                  <button onClick={handleStart} className="btn-primary">
                    <div className="flex items-center space-x-2">
                      <div className="icon-play text-lg"></div>
                      <span>Démarrer</span>
                    </div>
                  </button>
                ) : (
                  <button onClick={() => setIsRunning(false)} className="btn-primary">
                    <div className="flex items-center space-x-2">
                      <div className="icon-pause text-lg"></div>
                      <span>Pause</span>
                    </div>
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="card text-center">
              <div className="icon-check-circle text-6xl mb-4 mx-auto" style={{color: 'var(--primary-color)'}}></div>
              <h2 className="text-2xl font-bold mb-4">Session terminée !</h2>
              <p className="mb-6" style={{color: 'var(--text-secondary)'}}>
                Comment évaluez-vous cette session ?
              </p>
              <div className="flex justify-center space-x-2">
                {[0, 1, 2, 3, 4, 5].map(q => (
                  <button
                    key={q}
                    onClick={() => handleQualitySubmit(q)}
                    className="w-12 h-12 rounded-lg border-2 hover:bg-gray-100"
                    style={{borderColor: 'var(--border-color)'}}
                  >
                    {q}
                  </button>
                ))}
              </div>
              <p className="text-sm mt-4" style={{color: 'var(--text-secondary)'}}>
                0 = Très difficile, 5 = Très facile
              </p>
            </div>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('PomodoroApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<PomodoroApp />);