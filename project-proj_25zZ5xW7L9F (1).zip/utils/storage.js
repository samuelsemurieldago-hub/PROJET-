const StorageManager = {
  getCourses: () => {
    const data = localStorage.getItem('courses');
    return data ? JSON.parse(data) : [];
  },
  
  saveCourses: (courses) => {
    localStorage.setItem('courses', JSON.stringify(courses));
  },
  
  getSubjects: () => {
    const data = localStorage.getItem('subjects');
    return data ? JSON.parse(data) : [];
  },
  
  saveSubjects: (subjects) => {
    localStorage.setItem('subjects', JSON.stringify(subjects));
  },
  
  getSessions: () => {
    const data = localStorage.getItem('sessions');
    return data ? JSON.parse(data) : [];
  },
  
  saveSessions: (sessions) => {
    localStorage.setItem('sessions', JSON.stringify(sessions));
  },
  
  addSession: (session) => {
    const sessions = StorageManager.getSessions();
    sessions.push({
      ...session,
      id: Date.now().toString(),
      timestamp: new Date().toISOString()
    });
    StorageManager.saveSessions(sessions);
    return sessions;
  }
};