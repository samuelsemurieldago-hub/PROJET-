const SM2Algorithm = {
  calculateNextReview: (quality, repetitions, easeFactor, interval) => {
    if (quality < 3) {
      return {
        repetitions: 0,
        interval: 1,
        easeFactor: easeFactor
      };
    }
    
    let newEaseFactor = easeFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
    if (newEaseFactor < 1.3) newEaseFactor = 1.3;
    
    let newInterval;
    if (repetitions === 0) {
      newInterval = 1;
    } else if (repetitions === 1) {
      newInterval = 6;
    } else {
      newInterval = Math.round(interval * newEaseFactor);
    }
    
    return {
      repetitions: repetitions + 1,
      interval: newInterval,
      easeFactor: newEaseFactor,
      nextReview: new Date(Date.now() + newInterval * 24 * 60 * 60 * 1000).toISOString()
    };
  },
  
  updateSubjectAfterSession: (subject, quality) => {
    const result = SM2Algorithm.calculateNextReview(
      quality,
      subject.repetitions || 0,
      subject.easeFactor || 2.5,
      subject.interval || 0
    );
    
    return {
      ...subject,
      ...result,
      lastReview: new Date().toISOString()
    };
  }
};