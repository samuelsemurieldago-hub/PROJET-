function PlanningApp() {
  try {
    const [courses, setCourses] = React.useState([]);
    const days = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
    const hours = Array.from({length: 15}, (_, i) => i + 7);

    React.useEffect(() => {
      setCourses(StorageManager.getCourses());
    }, []);

    const getCoursesForDay = (day) => {
      return courses.filter(c => c.day === day);
    };

    return (
      <div className="min-h-screen" data-name="planning-app" data-file="planning-app.js">
        <Navigation currentPage="planning" />
        <div className="container mx-auto px-4 py-8">
          <div className="mb-6">
            <h1 className="text-3xl font-bold mb-2" style={{color: 'var(--text-primary)'}}>
              Mon Planning
            </h1>
            <p style={{color: 'var(--text-secondary)'}}>
              Visualisez votre emploi du temps de la semaine
            </p>
          </div>

          <div className="card overflow-x-auto">
            <div className="grid grid-cols-8 gap-2 min-w-max">
              <div className="font-medium p-2">Heure</div>
              {days.map(day => (
                <div key={day} className="font-medium p-2 text-center">
                  {day}
                </div>
              ))}
              
              {hours.map(hour => (
                <React.Fragment key={hour}>
                  <div className="p-2 text-sm" style={{color: 'var(--text-secondary)'}}>
                    {hour}:00
                  </div>
                  {days.map(day => {
                    const dayCourses = getCoursesForDay(day).filter(c => {
                      const courseHour = parseInt(c.startTime.split(':')[0]);
                      return courseHour === hour;
                    });
                    
                    return (
                      <div key={`${day}-${hour}`} className="p-2 border rounded-lg min-h-[60px]" style={{borderColor: 'var(--border-color)'}}>
                        {dayCourses.map((course, idx) => (
                          <div 
                            key={idx}
                            className="p-2 rounded text-sm mb-1"
                            style={{
                              backgroundColor: course.type === 'course' ? 'var(--secondary-color)' : '#FEF3C7',
                              color: 'var(--text-primary)'
                            }}
                          >
                            <div className="font-medium">{course.name}</div>
                            <div className="text-xs">{course.startTime} - {course.endTime}</div>
                          </div>
                        ))}
                      </div>
                    );
                  })}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('PlanningApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<PlanningApp />);